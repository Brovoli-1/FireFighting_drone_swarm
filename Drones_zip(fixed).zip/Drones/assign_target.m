function target = assign_target(drone, fire, params)
% ASSIGN_TARGET  Choose a burning cell for this drone to move toward.
%
% Inputs:
%   drone.pos          - [row, col] current drone position
%   fire.intensity     - 2D matrix of fire intensities (0 to 1)
%   params.search_radius (optional) - sensing radius (cells)
%
% Outputs:
%   target             - [row, col] of selected fire cell, or [] if none

F = fire.intensity;
[rows, cols] = size(F);

% Find all burning cells
[ri, ci] = find(F > 0);
if isempty(ri)
    target = [];
    return;
end

drPos = drone.pos(:)';          % [row, col]
diffs = [ri, ci] - drPos;       % N x 2
dists = sqrt(sum(diffs.^2, 2)); % distances

% Optional: restrict by search_radius
if isfield(params, "search_radius")
    mask  = dists <= params.search_radius;
    ri    = ri(mask);
    ci    = ci(mask);
    dists = dists(mask);
    if isempty(ri)
        target = [];
        return;
    end
end

idx   = sub2ind([rows, cols], ri, ci);
fires = F(idx);

% Score = intensity / distance → favor hot and nearby fires
score = fires ./ (dists + 1e-6);
[~, k] = max(score);

target = [ri(k), ci(k)];
end
