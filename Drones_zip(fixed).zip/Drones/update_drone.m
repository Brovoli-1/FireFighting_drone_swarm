function drone = update_drone(drone, fire, params)
% UPDATE_DRONE  Perform one update step for a single drone.
%
% Logic:
%   - If ACTIVE and no valid target, call ASSIGN_TARGET.
%   - Propose a movement step toward the target (stored in proposed_pos).
%
% Inputs:
%   drone              - drone struct (pos, target, state, speed, proposed_pos)
%   fire.intensity     - 2D fire intensity grid
%   params.grid_size   - [rows, cols] for boundary checking
%   params.drone_speed - scalar movement speed
%
% Outputs:
%   drone              - updated drone struct with new target and proposed_pos

if ~isfield(drone, "state") || isempty(drone.state)
    drone.state = "ACTIVE";
end

if drone.state == "ACTIVE"
    % Validate or assign target
    if isempty(drone.target)
        drone.target = assign_target(drone, fire, params);
    else
        rows = params.grid_size(1);
        cols = params.grid_size(2);
        r = drone.target(1);
        c = drone.target(2);
        out_of_bounds = (r < 1 || r > rows || c < 1 || c > cols);
        target_gone   = ~out_of_bounds && fire.intensity(r, c) <= 0;
        if out_of_bounds || target_gone
            drone.target = assign_target(drone, fire, params);
        end
    end
end

% Default: stay in place
drone.proposed_pos = drone.pos;

% Propose move toward target if we have one
if ~isempty(drone.target)
    delta = drone.target - drone.pos;
    if ~all(delta == 0)
        step    = sign(delta);           % direction on each axis
        maxStep = drone.speed;
        step    = max(min(step, maxStep), -maxStep);

        newPos = drone.pos + step;

        % Keep inside grid
        rows = params.grid_size(1);
        cols = params.grid_size(2);
        newPos(1) = min(max(newPos(1), 1), rows);
        newPos(2) = min(max(newPos(2), 1), cols);

        drone.proposed_pos = newPos;
    end
end
end
