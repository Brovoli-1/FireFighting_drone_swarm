function drones = init_drones(params)
% INIT_DRONES  Create and initialize the drone struct array.
%
% Inputs:
%   params.grid_size   - [rows, cols] size of the fire grid
%   params.num_drones  - number of drones to create
%   params.drone_speed - movement speed (cells per time step)
%   params.avoid_radius- radius for collision avoidance
%
% Outputs:
%   drones             - 1 x N struct array with fields:
%       id           - unique integer ID
%       pos          - [row, col] current position
%       target       - [row, col] current fire target (or [])
%       state        - "ACTIVE" (default)
%       speed        - scalar speed (from params.drone_speed)
%       proposed_pos - [row, col] next intended position
%       avoid_radius - scalar radius for neighbor detection
%       avoid_vector - [drow, dcol] avoidance steering vector
%       priority     - scalar used to break move ties
%       safe         - logical flag set by avoidance / collisions

N    = params.num_drones;
rows = params.grid_size(1);
cols = params.grid_size(2);

drones(1:N) = struct();

for i = 1:N
    drones(i).id           = i;
    drones(i).pos          = [randi(rows), randi(cols)];
    drones(i).target       = [];
    drones(i).state        = "ACTIVE";
    drones(i).speed        = params.drone_speed;
    drones(i).proposed_pos = drones(i).pos;
    drones(i).avoid_radius = params.avoid_radius;
    drones(i).avoid_vector = [0, 0];
    drones(i).priority     = rand;
    drones(i).safe         = true;
end
end
