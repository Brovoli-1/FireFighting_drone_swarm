function drones = detect_avoid(drones, params)
% DETECT_AVOID  Apply collision avoidance and finalize drone positions.
%
% Steps:
%   1) Use each drone's proposed_pos as its intended move.
%   2) Add a soft avoidance adjustment away from nearby drones.
%   3) Enforce that no two drones share a cell (resolve collisions).
%
% Inputs:
%   drones             - 1 x N array of drone structs with:
%                        pos, proposed_pos, avoid_radius, avoid_vector, priority
%   params.grid_size   - [rows, cols]
%   params.avoid_weight- weight for avoidance adjustment
%
% Outputs:
%   drones             - updated drone structs with:
%                        pos (final), avoid_vector, safe (collision info)

N = numel(drones);
current_positions = zeros(N, 2);
proposals         = zeros(N, 2);
priorities        = zeros(N, 1);

for i = 1:N
    current_positions(i, :) = drones(i).pos;
    proposals(i, :)         = drones(i).proposed_pos;
    priorities(i)           = drones(i).priority;
end

% Soft avoidance: steer away from neighbors within avoid_radius
for i = 1:N
    pos_i = current_positions(i, :);
    R     = drones(i).avoid_radius;
    repel = [0, 0];

    for j = 1:N
        if j == i, continue; end
        pos_j = current_positions(j, :);
        diff  = pos_i - pos_j;
        dist  = norm(diff);
        if dist > 0 && dist <= R
            repel = repel + diff / (dist^2);
        end
    end

    drones(i).avoid_vector = repel;

    if any(repel ~= 0)
        stepAvoid = sign(repel);
        w         = params.avoid_weight;
        proposals(i, :) = proposals(i, :) + w * stepAvoid;

        rows = params.grid_size(1);
        cols = params.grid_size(2);
        proposals(i, 1) = min(max(proposals(i, 1), 1), rows);
        proposals(i, 2) = min(max(proposals(i, 2), 1), cols);
    end
end

% Hard collision resolution: no two drones in the same cell
[new_positions, safeFlags] = resolve_collisions(proposals, current_positions, priorities);

for i = 1:N
    drones(i).pos  = round(new_positions(i, :));
    drones(i).safe = safeFlags(i);
end
end



function [new_positions, safeFlags] = resolve_collisions(proposals, current_positions, priorities)

N             = size(proposals, 1);
new_positions = current_positions;
safeFlags     = true(N, 1);
used          = false(N, 1);

for i = 1:N
    if used(i), continue; end

    same = all(proposals == proposals(i, :), 2);
    idx  = find(same);
    used(idx) = true;

    if numel(idx) == 1
        new_positions(idx, :) = proposals(idx, :);
        safeFlags(idx)        = true;
    else
        [~, localWinner] = max(priorities(idx));
        winner = idx(localWinner);

        new_positions(winner, :) = proposals(winner, :);
        safeFlags(winner)        = false;

        losers = setdiff(idx, winner);
        for L = losers(:)'
            safeFlags(L) = false;
        end
    end
end
end
