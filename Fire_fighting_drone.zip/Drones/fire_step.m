function fire = fire_step(fire, params)
% FIRE_STEP - Cellular automaton fire update:
%  1) orthogonal spread from burning cells (N,S,E,W)
%  2) global decay
%  3) clamp to [0,1] using clamp01 utility

    old = fire.intensity;
    new = old;

    [R, C] = size(old);

    % Spread to orthogonal neighbors
    for r = 1:R
        for c = 1:C
            intensity = old(r,c);
            if intensity > 0.1
                add = params.spread_rate * intensity;
                if r > 1,    new(r-1, c) = new(r-1, c) + add; end
                if r < R,    new(r+1, c) = new(r+1, c) + add; end
                if c > 1,    new(r, c-1) = new(r, c-1) + add; end
                if c < C,    new(r, c+1) = new(r, c+1) + add; end
            end
        end
    end

    % Global decay
    new = new - params.decay_rate;

    % Clamp to [0,1]
    new = clamp01(new);

    fire.intensity = new;
end
