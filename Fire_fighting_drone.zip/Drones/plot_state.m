function plot_state(fire, drones, params)
% PLOT_STATE - Render heatmap of fire.intensity and overlay drones.
% Expects drones(i).pos as [row,col].

    imagesc(fire.intensity);
    colormap('hot');
    colorbar;
    axis equal tight;
    hold on;

    for i = 1:numel(drones)
        r = drones(i).pos(1);
        c = drones(i).pos(2);
        % plot uses x=col, y=row
        plot(c, r, 'o', 'MarkerSize', 8, 'LineWidth', 2, 'MarkerFaceColor', 'b');
        txt = sprintf('D%d', drones(i).id);
        text(c + 0.3, r, txt, 'Color', 'w', 'FontSize', 8);
    end

    if isfield(params, 'current_time')
        title(sprintf('Fire intensity (t = %.2f s)', params.current_time));
    else
        title('Fire intensity');
    end

    drawnow;
    hold off;
end
