function summarize_results(fire, drones, params)
% SUMMARIZE_RESULTS - Create a simple summary table and save outputs.
% Note: original drone struct does not track per-drone extinguish counts or logs;
%       this function summarizes final positions, priority, and safety flags.

    N = numel(drones);
    % Acquire total extinguished cells (compared to threshold)
    total_cells = numel(fire.intensity);
    remaining_burning = sum(fire.intensity(:) > params.stop_threshold);
    extinguished_cells = total_cells - remaining_burning;

    for i = 1:N
        out(i).Drone_ID = drones(i).id;
        out(i).Final_Row = drones(i).pos(1);
        out(i).Final_Col = drones(i).pos(2);
        if isfield(drones(i), 'priority')
            out(i).Priority = drones(i).priority;
        else
            out(i).Priority = NaN;
        end
        if isfield(drones(i), 'safe')
            out(i).Safe = drones(i).safe;
        else
            out(i).Safe = true;
        end
    end

    tbl = struct2table(out);

    % Add overall metrics
    fprintf('Simulation finished.\n');
    fprintf('Total grid cells: %d\n', total_cells);
    fprintf('Cells extinguished (final): %d\n', extinguished_cells);
    fprintf('Cells still burning (intensity > %.2f): %d\n', params.stop_threshold, remaining_burning);

    % Save outputs
    writetable(tbl, 'summary.csv');
    save('results.mat', 'fire', 'drones', 'params', 'tbl');

    % Display the table
    disp(tbl);
end
