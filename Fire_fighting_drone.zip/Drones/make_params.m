function params = make_params()
% MAKE_PARAMS - Simulation parameters used across functions
    params.grid_size         = [30, 30];   % [rows, cols]
    params.dt                = 0.1;        % timestep (s)
    params.max_time          = 200;        % simulation duration (s)
    params.stop_threshold    = 0.1;        % stop when all cells < this
    params.spread_rate       = 0.08;       % fraction spread from burning cells to neighbors
    params.decay_rate        = 0.028;       % global decay per step
    params.num_drones        = 5;          % minimum: 3 drones
    params.drone_speed       = 1;          % cells per timestep
    params.avoid_radius      = 1;          % used by your init_drones/detect_avoid
    params.avoid_weight      = 2;        % used by your detect_avoid soft avoidance
    params.search_radius     = 200;          % used by your assign_target
    params.visualize         = true;       % show live plot
    params.visualize_every_n = 1;          % redraw every N steps
    params.rng_seed          = 42;         % deterministic randomness
end
