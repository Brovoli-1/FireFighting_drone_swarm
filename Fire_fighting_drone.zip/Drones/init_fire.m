function fire = init_fire(params)
% INIT_FIRE - Build initial fire struct with intensity grid
% Places a few initial fire seeds with random intensities in [0.5, 1.0].

    rng(params.rng_seed + 10); % different stream for fire seeds
    rows = params.grid_size(1);
    cols = params.grid_size(2);

    fire.intensity = zeros(rows, cols);

    num_start_fires = 3; % can be adjusted
    for n = 1:num_start_fires
        r = randi(rows);
        c = randi(cols);
        fire.intensity(r, c) = rand()*0.5 + 0.5; % 0.5 - 1.0
    end
end
