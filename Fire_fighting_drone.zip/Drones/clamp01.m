function result = clamp01(values)
% CLAMP01 - Keep matrix values within [0,1]
    result = min(max(values, 0), 1);
end
