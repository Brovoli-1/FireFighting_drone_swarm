function drone = update_drone(drone, fire, params)
% UPDATE_DRONE  Perform one update step for a single drone.
%
% Logic:
%   - If ACTIVE and no valid target, call ASSIGN_TARGET.
%   - Propose a movement step toward the target (stored in proposed_pos).
%   - Extinguish fire in nearby cells.
%
% Inputs:
%   drone              - drone struct (pos, target, state, speed, proposed_pos)
%   fire.intensity     - 2D fire intensity grid
%   params.grid_size   - [rows, cols] for boundary checking
%   params.drone_speed - scalar movement speed
%
% Outputs:
%   drone              - updated drone struct with new target and proposed_pos

% --- New fire-fighting parameters (added) ---
if ~isfield(params, "drop_radius"), params.drop_radius = 2; end
if ~isfield(params, "water_drop"), params.water_drop = 0.4; end
if ~isfield(params, "detect_radius"), params.detect_radius = 8; end

% Ensure state is defined
if ~isfield(drone, "state") || isempty(drone.state)
    drone.state = "ACTIVE";
end

if drone.state == "ACTIVE"
    % Validate or assign target
    if isempty(drone.target)
        drone.target = assign_target(drone, fire, params);
    else
        rows = params.grid_size(1);
        cols = params.grid_size(2);
        r = drone.target(1);
        c = drone.target(2);
        out_of_bounds = (r < 1 || r > rows || c < 1 || c > cols);
        target_gone   = ~out_of_bounds && fire.intensity(r, c) <= 0;
        if out_of_bounds || target_gone
            drone.target = assign_target(drone, fire, params);
        end
    end
    
    % --- NEW: Fire detection refresh ---
    % Re-scan for nearby fires every time step if target is stale or gone
    if isempty(drone.target) || rand < 0.2
        newTarget = assign_target(drone, fire, params);
        if ~isempty(newTarget)
            drone.target = newTarget;
        end
    end
end

% Default: stay in place
drone.proposed_pos = drone.pos;

% Propose move toward target if we have one
if ~isempty(drone.target)
    delta = drone.target - drone.pos;
    if ~all(delta == 0)
        step    = sign(delta);           % direction on each axis
        maxStep = drone.speed;
        step    = max(min(step, maxStep), -maxStep);

        newPos = drone.pos + step;

        % Keep inside grid
        rows = params.grid_size(1);
        cols = params.grid_size(2);
        newPos(1) = min(max(newPos(1), 1), rows);
        newPos(2) = min(max(newPos(2), 1), cols);

        drone.proposed_pos = newPos;
    end
end

% --- NEW: Extinguish nearby fire around drone position ---
if isfield(fire, "intensity")
    fire_map = fire.intensity;
    r = round(drone.pos(1));
    c = round(drone.pos(2));
    rows = size(fire_map, 1);
    cols = size(fire_map, 2);

    for dr = -params.drop_radius:params.drop_radius
        for dc = -params.drop_radius:params.drop_radius
            rr = r + dr;
            cc = c + dc;
            if rr >= 1 && rr <= rows && cc >= 1 && cc <= cols
                fire_map(rr, cc) = fire_map(rr, cc) - params.water_drop;
            end
        end
    end

    fire.intensity = clamp01(fire_map);  % keep between 0–1
end

end
