function driver()
% DRIVER - Entry point for FireSwarm_GroupX
% Uses the team's original functions (init_drones, update_drone, detect_avoid, assign_target).

    % Setup
    params = make_params();
    rng(params.rng_seed);

    fire   = init_fire(params);
    drones = init_drones(params);

    time = 0;
    step = 0;

    if params.visualize
        figure('Name','FireSwarm Simulation','NumberTitle','off');
    end

    % Main loop: stop when time limit reached OR largest fire intensity below threshold
    while (time < params.max_time) && (max(fire.intensity, [], 'all') > params.stop_threshold)
        step = step + 1;

        % Fire update (spread -> decay -> clamp)
        fire = fire_step(fire, params);

        % Per-drone update: target selection and proposed move
        for i = 1:numel(drones)
            drones(i) = update_drone(drones(i), fire, params);
        end

        % Collision avoidance + finalize positions (uses original detect_avoid)
        drones = detect_avoid(drones, params);

        % Drop water at each drone's current position (instant extinguish at cell)
        for i = 1:numel(drones)
            pos = round(drones(i).pos);
            r = pos(1); c = pos(2);
            % Safety: ensure indices inside grid
            r = min(max(1, r), params.grid_size(1));
            c = min(max(1, c), params.grid_size(2));
            fire.intensity(r, c) = 0;
        end

        % Visualization
        if params.visualize && mod(step, params.visualize_every_n) == 0
            params.current_time = time;
            plot_state(fire, drones, params);
        end

        % Advance time
        time = time + params.dt;
    end

    % Final outputs
    summarize_results(fire, drones, params);
end
